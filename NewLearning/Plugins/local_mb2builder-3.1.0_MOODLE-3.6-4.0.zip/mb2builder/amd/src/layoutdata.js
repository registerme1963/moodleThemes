// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 *
 * @package    local_mb2builder
 * @copyright  2018 - 2022 Mariusz Boloz (mb2themes.com)
 * @license    Commercial https://themeforest.net/licenses
 */ define(["jquery","local_mb2builder/selectors","local_mb2builder/helper"],function($,a,b){return{setData:function(c){var d=[];return(c?$(a.builder.demoiframe).contents().find(a.builder.buildercontainer):$(a.builder.buildercontainer)).each(function(f){var c=$(this),g=f,e=b.dataAttribs(c);delete e.sortableItem,d[g]={type:"mb2pb_page",settings:e,attr:[]},c.find(a.layout.section).each(function(f){var c=$(this),h=f,e=b.dataAttribs(c);delete e.sortableItem,d[g].attr[h]={type:"mb2pb_section",settings:e,attr:[]},c.find(a.layout.row).each(function(f){var c=$(this),i=f,e=b.dataAttribs(c);delete e.sortableItem,d[g].attr[h].attr[i]={type:"mb2pb_row",settings:e,attr:[]},c.find(a.layout.pbcolumn).each(function(f){var c=$(this),j=f,e=b.dataAttribs(c);delete e.sortableItem,d[g].attr[h].attr[i].attr[j]={type:"mb2pb_col",settings:e,attr:[]},c.find(a.layout.element).each(function(f){var c=$(this),k=f,e=b.dataAttribs(c);delete e.sortableItem,d[g].attr[h].attr[i].attr[j].attr[k]={type:"mb2pb_el",settings:e,attr:[]},c.find(a.layout.subelement).each(function(c){var e=$(this),f=c,a=b.dataAttribs(e);delete a.sortableItem,d[g].attr[h].attr[i].attr[j].attr[k].attr[f]={type:"mb2pb_subel",settings:a,attr:[]}})})})})})}),d}}})
