// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 *
 * @package    local_mb2builder
 * @copyright  2018 - 2022 Mariusz Boloz (mb2themes.com)
 * @license    Commercial https://themeforest.net/licenses
 */ define(["jquery","local_mb2builder/selectors"],function($,a){var d=$(a.builder.langspan),b=function(a){if(""!==a)return a=(a=a.replace(/\[.+\]/g,d.data("shortcodereplaced"))).replace("GENERICO","GENERIC0")},c=function(b){b?$(a.builder.overlay).fadeIn(180):$(a.builder.overlay).fadeOut(180)};return{replaceText:b,dataAttribs:function(a){var c={};return $.each(a[0].attributes,function(){this.name.includes("data-")&&!this.name.includes("data-jarallax-")&&this.specified&&(c[this.name.replace("data-","")]=b(this.value))}),c},overlay:c,reload:function(){var b=window.parent.$(a.builder.demoiframe);c(!0),b.attr("src",b.attr("src"))},modalSettings:function(){$(a.builder.modal).draggable({cursor:"move",handle:a.builder.modalheader,scroll:!1})},checkModal:function(a){return!$(".modal.show").length||(alert(d.data("cantopenmodal")),!1)},decodeSpecialHtml:function(a){if(void 0!==a)return"number"==typeof a?a:a.replace(/&#34;/g,'"').replace(/&#39;/g,"'").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&amp;/g,"&")},classFromnum:function(a,d,f){var b=[0,50,100,150,200,250],c=0,e=a.attr("data-sizepref")+"-";for(f&&(b=[1,2,3,4,5]),"column"===a.attr("data-numclasselector")&&(d=$(".mb2-pb-column-active")),c=0;c<b.length;c++)(f?a.val()>b[c]:a.val()>=b[c])&&(d.removeClass(e+b.join(" "+e)),d.addClass(e+b[c]),a.attr("data-numclassattr")&&d.attr("data-"+a.attr("data-numclassattr"),b[c]),a.attr("data-setval")&&$(".modal.show").find('[data-attrname="'+a.attr("data-setval")+'"]').val(b[c]))},stripHtml:function(a,b){return"html"===b?a:a.replace(/<\/?[^>]+(>|$)/g,"")},checkImage:function(a){return a?a.toLowerCase().match(/\.(jpg|jpeg|png|gif)/g)||a.includes("sample-data")?1:2:0},getSection:function(a){return"settings-section"===a?section=$(".mb2-pb-section-active"):"settings-row"===a?section=$(".mb2-pb-row-active"):"settings-column"===a?section=$(".mb2-pb-column-active"):"settings-element"===a?section=$(".mb2-pb-element-active"):"settings-subelement"===a&&(section=$(".mb2-pb-subelement-active")),section},validHtml:function(a){var b=new DOMParser;a="<div>"+a+"</div>";var c=b.parseFromString(a,"application/xml").querySelector("parsererror");return""===a?1:c?(alert(d.data("htmlerror")),0):1},screenSize:function(c){var b=$(a.builder.demoiframe);b.removeClass("device-desktop device-tablet device-smartphone"),b.addClass("device-"+c)},uniqId:function(){return Math.floor(1e4*Math.random())}}})
