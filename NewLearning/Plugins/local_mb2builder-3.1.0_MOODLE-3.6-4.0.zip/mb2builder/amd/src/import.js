// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 *
 * @package    local_mb2builder
 * @copyright  2018 - 2022 Mariusz Boloz (mb2themes.com)
 * @license    Commercial https://themeforest.net/licenses
 */ define(["jquery","local_mb2builder/selectors","local_mb2builder/helper","local_mb2builder/senddemo","local_mb2builder/carousel","local_mb2builder/layout","local_mb2builder/parallax","local_mb2builder/elements"],function($,a,b,c,d,e,f,g){var h=$(a.builder.langspan);return{customLayout:function(i){var l=i,m=$('[name="importlayoutkeep"]');if(0==$("#importlayoutid").val())return $("#importlayoutid").css("border-color","red"),$("#importlayoutid").closest("div").find(".mb2-pb-error").show(),null;$("#importlayoutid").attr("style",""),$("#importlayoutid").closest("div").find(".mb2-pb-error").hide(),b.overlay(!0);var j=i.find(".btn");j.val(h.data("processing")),j.attr("disabled","disabled");var k=i.attr("data-url");$.ajax({type:"POST",url:k,data:i.serialize(),dataType:"html",beforeSend:function(){},error:function(a,b,c){},success:function(i){$("#importlayoutid").val(0),m.prop("checked")?$(a.builder.buildercontainer).first().find(a.layout.container_sections).append(i):$(a.builder.buildercontainer).first().find(a.layout.container_sections).html(i),c.saveDemo(),b.overlay(!1),e.layoutInit(),$(a.builder.buildercontainer).find(a.layout.carousel).each(function(){d.carouselInit($(this).attr("id"))}),$(a.builder.buildercontainer).find(".parallax1").each(function(){f.parallaxInit($(this))}),$(a.builder.buildercontainer).find(a.elements.animnum).each(function(){g.animnumInit($(this),!1)}),setTimeout(function(){j.removeAttr("disabled"),j.val(h.data("importlayoutbtn")),l.find(".mb2-pb-success").show(),setTimeout(function(){l.find(".mb2-pb-success").hide()},1e4)},600)}})},predefinedPart:function(i){var k=i.attr("data-part"),h=b.dataAttribs(i);h=jQuery.param(h);var j=$(a.settings.settings).data("baseurl")+"/local/mb2builder/ajax/import-blocks.php?"+h+"&sesskey="+$(a.settings.settings).attr("data-sesskey");b.overlay(!0),$.ajax({url:j,type:"get",dataType:"html",beforeSend:function(){},error:function(a,b,c){},success:function(h){if("layouts"===k)$(a.builder.buildercontainer).find(a.layout.container_sections).html(h);else{var i=$(a.layout.section).first().find(a.layout.container_rows);i.append(h);var j=i.find($(a.layout.startbuttons));j.length&&j.remove()}c.saveDemo(),b.overlay(!1),e.layoutInit(),$(a.builder.buildercontainer).find(a.layout.carousel).each(function(){d.carouselInit($(this).attr("id"))}),$(a.builder.buildercontainer).find(".parallax1").each(function(){f.parallaxInit($(this))}),$(a.builder.buildercontainer).find(a.elements.animnum).each(function(){g.animnumInit($(this),!1)})}})}}})
