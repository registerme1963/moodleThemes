// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 *
 * @package    local_mb2builder
 * @copyright  2018 - 2022 Mariusz Boloz (mb2themes.com)
 * @license    Commercial https://themeforest.net/licenses
 */
define(["jquery","local_mb2builder/layout","local_mb2builder/helper","local_mb2builder/selectors","local_mb2builder/layoutdata"],function($,a,b,c,d){var e=function(){$(".mb2-pb-import-select select").each(function(a){$(this).on("change",function(){var a=$(this).val();$(this).closest(".tab-pane").find(".block-item").each(function(){""===a||a===$(this).attr("data-category")?$(this).show():$(this).hide()})})})},f=function(){$(c.layout.section).each(function(){""===$(this).find(c.layout.container_rows).html()&&$(c.layout.container_rows).html(a.startButtonsHtml())})};return{init:function(){a.layoutInit(),b.overlay(!1),b.modalSettings(),e(),f()},savePage:function(){$(".pagelayout-mb2builder_form .mform").on("submit",function(){var a=JSON.stringify(d.setData(!0));$('[name="content"]').val(a),$('[name="democontent"]').val(a)})},changeScreenSize:function(){$(document).on("click",c.builder.device,function(a){b.screenSize($(this).attr("data-device"))})}}})
