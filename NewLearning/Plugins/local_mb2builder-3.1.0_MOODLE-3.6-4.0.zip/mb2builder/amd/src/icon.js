// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 *
 * @package    local_mb2builder
 * @copyright  2018 - 2022 Mariusz Boloz (mb2themes.com)
 * @license    Commercial https://themeforest.net/licenses
 */ define(["jquery","local_mb2builder/selectors","local_mb2builder/helper"],function($,a,b){return $(a.builder.langspan),{iconAction:function(f,d,g){var c=b.getSection(g),e=c;(d.attr("data-selector")&&(e=c.find(d.attr("data-selector"))),c.hasClass("mb2pb-button")&&e.closest(".btn-incon").removeClass("hidden"),c.attr("data-"+d.attr("data-attrname"),f),d.attr("data-globalparent"))?c.find(a.layout.subelement).each(function(){$(this).attr("data-"+d.attr("data-attrname"))||$(this).find(e).attr("class",f)}):e.attr("class",f)},iconRemoveAction:function(c,f){var d=b.getSection(f),e=d;(c.attr("data-selector")&&(e=d.find(c.attr("data-selector"))),d.hasClass("mb2pb-button")&&e.closest(".btn-incon").addClass("hidden"),c.attr("data-default")&&!c.attr("data-globalparent")&&d.attr("data-"+c.attr("data-attrname"),c.attr("data-default")),c.attr("data-default")&&c.attr("data-globalparent"))?(d.find(a.layout.subelement).each(function(){$(this).attr("data-"+c.attr("data-attrname"))||$(this).find(e).attr("class",c.attr("data-default"))}),d.attr("data-"+c.attr("data-attrname"),c.attr("data-default"))):c.attr("data-globalchild")?(d.attr("data-"+c.attr("data-attrname"),""),e.attr("class",d.closest(a.layout.element).attr("data-"+c.attr("data-attrname")))):c.attr("data-default")?e.attr("class",c.attr("data-default")):(d.attr("data-"+c.attr("data-attrname"),""),e.attr("class","hidden"))}}})
