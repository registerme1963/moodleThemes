<?php


$string['filtername'] = 'Mb2 Shortcodes';

$string['globalopts'] = 'Global options';
$string['globalopts_help'] = 'This field allow to set global options for shortcodes items. Each line consists separated by colon characters (:) shortcode_name:option_name:value. Fo example:<br><pre>accordion:accordion_active:0</pre>';
$string['pagetheme'] = 'Custom theme name';
