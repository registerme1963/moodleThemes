<?php

$string['configtitle'] = 'Block title';
$string['cocoon_steps_dark:addinstance'] = 'Add a new [Cocoon] Steps Dark block';
$string['cocoon_steps_dark:myaddinstance'] = 'Add a new [Cocoon] Steps Dark block to Dashboard';
$string['pluginname'] = '[Cocoon] Steps Dark';
