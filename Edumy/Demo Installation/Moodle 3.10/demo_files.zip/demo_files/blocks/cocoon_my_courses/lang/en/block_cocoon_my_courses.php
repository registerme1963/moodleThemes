<?php

$string['cocoon_my_courses:addinstance'] = 'Add a [Cocoon] My Courses block';
$string['cocoon_my_courses:myaddinstance'] = 'Add a [Cocoon] My Courses block to my moodle';
$string['pluginname'] = '[Cocoon] My Courses';
$string['cocoon_my_courses'] = '[Cocoon] My Courses';
$string['courseid'] = 'Course';
$string['editpagetitle'] = 'Featured courses - editing';
$string['featuredcourse'] = 'Featured course: {$a}';
$string['doadd'] = 'Check to add new featured course';
$string['missingcourseid'] = 'You must select a course.';
$string['sortorder'] = 'Sort order';
$string['missingsortorder'] = 'You must set a sort order.';
$string['deletelink'] = '<a href="{$a}">Delete</a>';
$string['delete_featuredcourse'] = 'Delete featured course';
$string['confirmdelete'] = 'Are you sure you want to delete this course from the list of featured courses?';
$string['config_title'] = 'Title';
