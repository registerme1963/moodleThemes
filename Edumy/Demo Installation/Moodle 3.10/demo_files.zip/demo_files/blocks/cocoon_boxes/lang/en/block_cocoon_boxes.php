<?php
$string['cocoon_boxes:addinstance'] = 'Add a new [Cocoon] Boxes block';
$string['cocoon_boxes:myaddinstance'] = 'Add a new [Cocoon] Boxes block to Dashboard';
$string['pluginname'] = '[Cocoon] Boxes';
