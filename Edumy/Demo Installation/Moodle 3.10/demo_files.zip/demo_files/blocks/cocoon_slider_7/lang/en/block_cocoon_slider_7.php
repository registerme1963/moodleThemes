<?php
$string['configtitle'] = 'Block title';
$string['cocoon_slider_7:addinstance'] = 'Add a new [Cocoon] Slider style 7 block';
$string['cocoon_slider_7:myaddinstance'] = 'Add a new [Cocoon] Slider style 7 block to Dashboard';
$string['pluginname'] = '[Cocoon] Slider style 7';
