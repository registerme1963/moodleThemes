<?php

$string['configtitle'] = 'Block title';
$string['cocoon_tstmnls_3:addinstance'] = 'Add a new [Cocoon] Testimonials slider 3 block';
$string['cocoon_tstmnls_3:myaddinstance'] = 'Add a new [Cocoon] Testimonials slider 3 block to Dashboard';
$string['pluginname'] = '[Cocoon] Testimonials slider 3';
