<?php
$string['pluginname'] = '[Cocoon] Featured Courses Masonry 6';
