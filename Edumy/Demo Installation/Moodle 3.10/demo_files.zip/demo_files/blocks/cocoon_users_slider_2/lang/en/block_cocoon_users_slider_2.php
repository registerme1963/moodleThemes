<?php

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = '[Cocoon] Users Slider Large';
$string['cocoon_users_slider_2_title'] = 'Title';
$string['cocoon_users_slider_2_users'] = 'Users';
$string['empty'] = 'The list is empty';

$string['cocoon_users_slider_2:addinstance'] = 'Add a cocoon_users_slider_2 users block';
$string['cocoon_users_slider_2:myaddinstance'] = 'Add a new cocoon_users_slider_2 users to the My Moodle page';
