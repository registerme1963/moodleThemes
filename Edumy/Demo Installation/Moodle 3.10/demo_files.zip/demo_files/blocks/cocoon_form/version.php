<?php
$plugin->component = 'block_cocoon_form';
$plugin->version   = 2021083004.11;
$plugin->requires = 2010112400;
