<?php
$string['pluginname'] = '[Cocoon] Parallax White';
$string['cocoon_parallax_white'] = '[Cocoon] Parallax White';
$string['cocoon_parallax_white:addinstance'] = 'Add a new Gallery block';
$string['cocoon_parallax_white:myaddinstance'] = 'Add a new Gallery block to the My Moodle page';
$string['config_title'] = 'Title';
$string['config_subtitle'] = 'Subtitle';
$string['config_button_text'] = 'Button text';
$string['config_button_link'] = 'Button link';
$string['config_image'] = 'Image';
