/* eslint-disable no-console */
/* eslint-disable no-unused-vars */
define(['jquery', 'core/ajax', 'core/templates'], function ($, Ajax, Templates) {
    const linkcoursecontent = '#linkcoursecontent';
    // const activeloading = ".loading.active";
    const activeloadingpane = ".tab-pane.active.loading";
    const loadingnavlink = ".nav-link.loading";
    const tabpanearea = ".tab-pane-area";
    const displayException = (ex) => {
        console.error(ex);
    };

    const activateContentLoading = (_thispane) => {
        var serviceName = $(_thispane).attr("data-service");
        var templateName = $(_thispane).attr("data-template");
        if (serviceName) {
            var autoservice = Ajax.call([{
                methodname: serviceName,
                args: {courseid: M.cfg.courseId}
            }]);
            autoservice[0].done(function(response) {
                console.log(response);
                Templates.renderForPromise(templateName, response)
                .then(({html, js}) => {
                    $(_thispane).find(tabpanearea).empty();
                    Templates.appendNodeContents(_thispane, html, js);
                    $('.nav-link[href="#'+$(_thispane).attr('id')+'"]').removeClass('loading');
                    $(_thispane).removeClass('loading');
                }).catch(ex => displayException(ex));
            }).fail(Notification.exception);
        }
    };

    return {
        init: function(){
            $(document).ready(function() {
                activateContentLoading(activeloadingpane);
                $(document).on('click', loadingnavlink, function(){
                    var loadContentForPane = $(this).attr("href");
                    activateContentLoading(loadContentForPane);
                });
            });
        }
    };
});
