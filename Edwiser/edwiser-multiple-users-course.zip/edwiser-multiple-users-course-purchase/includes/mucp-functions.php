<?php

namespace app\wisdmlabs\edwiserBridge\BulkPurchase;

function getUserProfileURL($userId = '', $with_a = true, $default = '&ndash;')
{
    $url = $default;

    $user_info = get_userdata($userId);

    if ($user_info) {
        $edit_link = get_edit_user_link($userId);
        $url = $with_a ? '<a class="mucp_username_redirection" href="'.esc_url($edit_link).'">'.$user_info->user_login.'</a>' : $edit_link;
    }

    return apply_filters('mucp_user_profile_url', $url, $userId, $with_a, $default);
}

/**
 * Updating cohort id in the order meta
 *@since 2.0.1
 */
function updateCohortIdInOrderMeta($orderId, $newCohortId, $quantity)
{
    $cohortData = get_post_meta($orderId, "eb_bp_mdl_cohort_id", 1);

    if ($cohortData) {
        $cohortData[$newCohortId] = $quantity;
        // array_push($cohortData, $newCohortId);
    } else {
        $cohortData = array($newCohortId => $quantity);
    }
    update_post_meta($orderId, "eb_bp_mdl_cohort_id", $cohortData);
}



function get_cohort_details($mdlCohortId)
{
    global $wpdb;
    $tablName = $wpdb->prefix . "bp_cohort_info";
    $query = $wpdb->prepare("SELECT MDL_COHORT_ID, PRODUCTS, COURSES, COHORT_NAME, NAME FROM $tablName WHERE mdl_cohort_id = %d", $mdlCohortId);
    $results = $wpdb->get_row($query, ARRAY_A);
    $productsArray = $results['PRODUCTS'];
    $products = unserialize($results['PRODUCTS']);
    $courses = unserialize($results['COURSES']);
    $products = array_values($products);
    $minQuantity = min($products);
    return array("quantity" => $minQuantity, "name" => $results['NAME'] != "" ? $results['NAME'] : $results['COHORT_NAME'], "courses" => $courses, "products" => $productsArray, "mdl_cohort_id" => $results['MDL_COHORT_ID']);
}


function eb_bp_get_wp_user_reg_role()
{
    $role       = '';
    $eb_options = get_option( 'eb_general' );
    if ( isset( $eb_options['eb_default_role'] ) && ! empty( $eb_options['eb_default_role'] ) ) {
        $role = apply_filters( 'eb_registration_role', $eb_options['eb_default_role'] );
    } else {
        $role = get_option( 'default_role' );
    }
    return $role;
}

