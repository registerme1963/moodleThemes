<?php

namespace app\wisdmlabs\edwiserBridge\BulkPurchase;

use app\wisdmlabs\edwiserBridge as edwiserBridge;

/**
 * Create new user and update the course enrollment of user.
 */
if (!class_exists('EdwiserMultipleUsersCoursePurchaseUserManager')) {

    class EdwiserMultipleUsersCoursePurchaseUserManager
    {

        /**
         * call to create user function for creating wordpress and moodle user.
         */
        public function __construct()
        {
            add_action('wp_ajax_create_wordpress_user', array($this, 'enroll_user_in_cohort'));
        }



        public function eb_update_pending_course_enrollment($user_id, $prdCourseArr)
        {
            $prodIds =  unserialize($prdCourseArr);
            $coursePostIds = $this->get_product_courses(array_keys($prodIds));

            //Adding thsi data to DB, so that the 2 way sync don't enroll the user again in the course.
            update_user_meta($user_id, 'eb_pending_enrollment', array_keys($coursePostIds));
        }

        public function eb_delete_pending_course_enrollment($user_id)
        {

            $prodIds=  unserialize($prdCourseArr);
            $coursePostIds=$this->get_product_courses(array_keys($prodIds));

            //Adding thsi data to DB, so that the 2 way sync don't enroll the user again in the course.
            delete_user_meta($user_id, 'eb_pending_enrollment');

        }


        /**
         * create wordpress and moodle user and enroll the user in cources.
         */
        public function enroll_user_in_cohort()
        {

            /**
             * Validae the request data.
             */
            if ($this->is_invalid_user_req_data($_POST)) {
                wp_send_json_error(__("Invalid user data.", 'ebbp-textdomain'));
            }
            /**
             * Declare the arrays for the messages.
             */
            $enrollmentErr       = array();
            $enrollmentSuc       = array();
            $alreadyEnrolledUser = array();
            $currUserId          = get_current_user_id();
            $details             = $this->get_cohort_details($_POST['mdl_cohort_id']);
            $remainingPrdCnt     = $details['quantity'];
            $mdlCohortId         = $details['mdl_cohort_id'];
            $firstNameArr        = $_POST['firstname'];
            $lastnNameArr        = $_POST['lastname'];
            $emailArr            = $_POST['email'];
            $userRole            = "Student";
            $wp_user_role        = eb_bp_get_wp_user_reg_role();
            $processed_users     = 0;
            $is_csv_users        = 0;
            
            /*$cohortName          = $details['name'];
            $ebCourseIds         = $details['courses'];
            $availableSeats      = $details['quantity'];
            $prdCourseArr        = $details['products'];*/
            

            if (isset($_POST['total']) && $_POST['total']) {
                $is_csv_users = 1;
            }

            /**
             * Check requested sets are available or not
             */
            if (count($emailArr) > $details['quantity']) {
                wp_send_json_error(__("Available sets quantity is less than requested quantity.", 'ebbp-textdomain'));
            }


            $users = array();

            for ($cnt = 0; $cnt < count($emailArr); $cnt++) {
                $status = false;

                if ($this->check_is_empty($firstNameArr, $cnt) && $this->check_is_empty($lastnNameArr, $cnt) && $this->check_is_empty($emailArr, $cnt)) {

                    $processed_users ++;

                    $first_name = $firstNameArr[$cnt];
                    $last_name  = $lastnNameArr[$cnt];
                    $email      = $emailArr[$cnt];
                    $user       = get_user_by('email', $email);
                    $password   = wp_generate_password();
                    $user_id    = 0;

                    // Creating WP user
                    if (email_exists($email)) {
                        $user      = get_user_by( 'email', $email );
                        $user_id   = $user->ID;
                        $user_name = $user->user_login;
                        // check if the user is already enrolled in the group.
                        // Remaining.
                        if ($this->is_user_already_enrolled($details['courses'], $user->ID)) {
                            $alreadyEnrolledUser[] = $user->user_email;
                            continue;
                        }
                    } else {

                        // $user_id = edwiserBridge\edwiserBridgeInstance()->userManager()->createWordpressUser($email, $firstname, $lastname);

                        // Create Only WP user
                        $user_name = sanitize_user(current(explode('@', $email)), true);

                        // Ensure username is unique
                        $append = 1;
                        $o_username = $user_name;

                        while (username_exists($user_name)) {
                            $user_name = $o_username.$append;
                            ++$append;
                        }

                        $wp_user_data = apply_filters(
                            'eb_bp_cohort_new_user_data',
                            array(
                                'user_login' => $user_name,
                                'first_name' => $first_name,
                                'last_name'  => $last_name,
                                'user_pass'  => $password,
                                'user_email' => $email,
                                'role'       => $wp_user_role,
                            )
                        );

                        $user_id = wp_insert_user($wp_user_data);

                        // Sending email.
                        $args = array(
                            'user_email' => $email,
                            'username'   => $user_name,
                            'first_name' => $first_name,
                            'last_name'  => $last_name,
                            'password'   => $password,
                        );
                        do_action('eb_created_user', $args);

                        if (is_wp_error($user_id)) {
                            continue;

                            /*$cohortManager = new BPCohortManageUser();
                            $cohortManager->updateMoodleUserProfile(5, $user->ID);*/
                        } else {
                            // Unable to create user.
                            // Add this user in the error message.
                        }
                    }


                    // create a array for API request.
                    array_push(
                        $users,
                        array(
                            'firstname' => $first_name,
                            'lastname'  => $last_name,
                            'password'  => $password,
                            'username'  => $user_name,
                            'email'     => $email,
                            // 'cohort_id'  => $mdlCohortId,
                        )
                    );

                }

                //Update pending Course enrollemngt entries so that 2 way sync won't get processed. 
                $this->eb_update_pending_course_enrollment($user_id, $details['products']);

            }

            if ($users && !empty($users)) {

                $connHelper = BPManageCohort::getEBConnectionHelper();
                $moodle_function = 'eb_manage_user_cohort_enrollment';
                $response = $connHelper->connectMoodleWithArgsHelper($moodle_function, array('cohort_id'=> $mdlCohortId, "users" => $users));

                //check common error of all users first like cohort exist or not.
                if (isset($response['success']) && $response['success'] && isset($response['response_data']->error) && $response['response_data']->error) {
                } elseif( isset( $response['response_data']->users ) ) {
                    foreach ( $response['response_data']->users as $moodle_user ) {
                    
                        // get the response['created'] data and check if the user created in Moodle if yes then update the moodle user id.
                        if ( ( isset( $moodle_user->creation_error ) && $moodle_user->creation_error ) || ( isset( $moodle_user->enrolled ) && ! $moodle_user->enrolled ) ) {
                        // create error array.   
                            $enrollmentErr[] = $moodle_user->email;
                        } else {
                            $user = get_user_by('email', $moodle_user->email);

                            if (!get_user_meta($user->ID, 'moodle_user_id', 1)) {

                                update_user_meta($user->ID, 'moodle_user_id', $moodle_user->user_id);
                                // Send email to the newly created users.
                                $args = array(
                                    'user_email' => $moodle_user->email,
                                    'username'   => $moodle_user->username,
                                    'first_name' => $user->first_name,
                                    'last_name'  => $user->last_name,
                                    'password'   => $moodle_user->password,
                                );
                                // create a new action hook with user details as argument.
                                do_action('eb_linked_to_existing_wordpress_user', $args);
                            }


                            // update data in WP.
                            $status = $this->enroll_user($mdlCohortId, $user->ID, $currUserId, $userRole, $details['products']);

                            // Send email
                            // $user = get_userdata($user_id);
                            $email_args = array(
                                'user_email' => $user->user_email,
                                'username' => $user->user_login,
                                'last_name' => $user->last_name,
                                'first_name' => $user->first_name,
                                'mdl_cohort_id' => $mdlCohortId,
                                'cohort_manager_id' => $currUserId,
                            );

                            do_action('eb_bp_new_user_to_cohort', $email_args);


                            $remainingPrdCnt--;
                            $this->update_bp_cohort_info_table_on_enrollment(
                                $mdlCohortId,
                                $remainingPrdCnt
                            );

                            // Update success users array.
                            $enrollmentSuc[] = $moodle_user->email;

                        }

                    }
                }
            }


            $currentUser = wp_get_current_user();
            $details['name']  = str_replace($currentUser->user_login . "_", "", $details['name']);
            $details['name'] .= " (" . $remainingPrdCnt . ") ";


            if ($is_csv_users && isset($_POST['total']) && isset($_POST['processed_users'])) {
                if ($_POST['total'] == ($_POST['processed_users'] + $processed_users)) {
                    $this->set_csv_users_response_data($currentUser->ID, $mdlCohortId, $enrollmentErr, $alreadyEnrolledUser, $enrollmentSuc);
                    $csv_response = $this->get_csv_users_response_data($currentUser->ID, $mdlCohortId, $enrollmentErr, $alreadyEnrolledUser, $enrollmentSuc);

                    $enrollmentErr       = $csv_response['enrollment_err'];
                    $alreadyEnrolledUser = $csv_response['already_enrolled_user'];
                    $enrollmentSuc       = $csv_response['enrollment_suc'];
                } else{
                    $this->set_csv_users_response_data($currentUser->ID, $mdlCohortId, $enrollmentErr, $alreadyEnrolledUser, $enrollmentSuc);
                }
            }


            /**
             * Prepare the responce messages and send responce.
             */
            wp_send_json_success(array("cohort" => html_entity_decode($details['name']), "msg" => $this->prepare_res_msg($enrollmentErr, $alreadyEnrolledUser, $enrollmentSuc, $is_csv_users), "processed_users" => $processed_users));
        }







        private function prepare_res_msg($enrollmentErr, $alreadyEnrolledUser, $enrollmentSuc, $is_csv_users)
        {
            ob_start();

            
            if (!empty($enrollmentSuc) && is_array($enrollmentSuc) && count($enrollmentSuc) > 0) {
                $msg = __("Users with following email ids have been enrolled successfully", 'ebbp-textdomain');

                if ($is_csv_users) {
                    ?>
                    <div>
                        <div class="ebbp_csv_enroll_error_msg wdm_success_message">
                            <i class="fa fa-times-circle wdm_success_msg_dismiss"></i>
                            <?php _e("Check enrolled users list ", 'ebbp-textdomain'); ?> <span class="ebbp_csv_enrollment_resp_pop_up" > <?php _e(" here ", 'ebbp-textdomain'); ?> </span> . 
                        </div>

                        <div class="ebbp_csv_enrollment_resp_msg_wrap">
                            <div class="ebbp_csv_enrollment_resp_msg" title="<?php  _e('Successfully Enrolled Users List', 'ebbp-textdomain'); ?>">

                    <?php
                }
                ?>
                <div class="wdm_success_message wdm_user_list">
                    <?php
                    if (!$is_csv_users) {
                        ?>
                            <i class="fa fa-times-circle wdm_success_msg_dismiss"></i>
                        <?php

                        $msg = __("User with following email id have been enrolled successfully", 'ebbp-textdomain');

                    }
                    ?>
                    <span class="wdm_enroll_warning_message_lable">
                        <?php echo $msg ?>
                    </span>
                    <?php echo $this->create_email_list($enrollmentSuc); ?>
                </div>
                <?php

                if ($is_csv_users){
                    ?>
                            </div>
                        </div>
                    </div>
                    <?php
                }


            }
            if (isset($alreadyEnrolledUser) && count($alreadyEnrolledUser) > 0) {

                $msg = __("User with the following email ids already enrolled in the courses", 'ebbp-textdomain');


                if ($is_csv_users) {
                    ?>
                    <div>
                        <div class="ebbp_csv_enroll_error_msg wdm_enroll_warning_message">
                            <i class="fa fa-times-circle wdm_enroll_warning_msg_dismiss"></i>
                            <?php _e(" Check already enrolled users  ", 'ebbp-textdomain'); ?> <span class="ebbp_csv_enrollment_resp_pop_up" > <?php _e(" here ", 'ebbp-textdomain'); ?> </span> . 
                        </div>
                        <div class="ebbp_csv_enrollment_resp_msg_wrap">
                            <div class="ebbp_csv_enrollment_resp_msg" title="<?php  _e('Already users List', 'ebbp-textdomain'); ?>">

                    <?php
                }
                ?>
                <div class="wdm_enroll_warning_message wdm_user_list">
                    <?php
                    if (!$is_csv_users) {
                    ?>
                        <i class="fa fa-times-circle wdm_enroll_warning_msg_dismiss"></i>
                    <?php

                    $msg = __("User with the following email id already enrolled in the courses", 'ebbp-textdomain');


                    }
                    ?>
                    <span class="wdm_enroll_warning_message_lable">
                        <?php echo $msg ?>
                    </span>
                    <?php echo $this->create_email_list($alreadyEnrolledUser); ?>
                </div>
                <?php
                if ($is_csv_users){
                    ?>
                            </div>
                        </div>
                    </div>

                    <?php
                }
            }

            if (!empty($enrollmentErr) && is_array($enrollmentErr) && count($enrollmentErr) > 0) {

                $msg = __("Some Error occured while enrolling users with following email ids:", 'ebbp-textdomain');


                if ($is_csv_users) {
                    ?>
                    <div>
                        <div class="ebbp_csv_enroll_error_msg wdm_error_message">
                            <i class="fa fa-times-circle wdm_error_msg_dismiss"></i>
                            <?php _e("Unable to enroll users in group, Check users list  ", 'ebbp-textdomain'); ?> <span class="ebbp_csv_enrollment_resp_pop_up" > <?php _e(" here ", 'ebbp-textdomain'); ?> </span> . 
                        </div>

                        <div class="ebbp_csv_enrollment_resp_msg_wrap">
                            <div class="ebbp_csv_enrollment_resp_msg" title="<?php  _e('Failed Enrollment Users', 'ebbp-textdomain'); ?>">

                    <?php
                }
                ?>
                <div class="wdm_error_message wdm_user_list">
                    <?php
                    if (!$is_csv_users) {
                    ?>
                        <i class="fa fa-times-circle wdm_error_msg_dismiss"></i>
                    <?php

                    $msg = __("Some Error occured while enrolling users with following email id:", 'ebbp-textdomain');
                    }
                    ?>
                    <span class="wdm_enroll_warning_message_lable">
                        <?php echo $msg ?>
                    </span>
                    <?php echo $this->create_email_list($enrollmentErr); ?>
                </div>
                <?php
                if ($is_csv_users){
                    ?>
                        </div>
                        </div>
                    </div>
                    <?php
                }
            }

            return ob_get_clean();
        }








        public function set_csv_users_response_data($user_id, $cohort_id, $enrollmentErr, $alreadyEnrolledUser, $enrollmentSuc)
        {

            $existing_data = get_option($user_id .'_'.$cohort_id);

            if (isset($existing_data) && !empty($existing_data)) {
                $enrollmentErr = array_merge($existing_data['enrollment_err'], $enrollmentErr);
                $alreadyEnrolledUser = array_merge($existing_data['already_enrolled_user'], $alreadyEnrolledUser);
                $enrollmentSuc = array_merge($existing_data['enrollment_suc'], $enrollmentSuc);
            }

            update_option($user_id .'_'.$cohort_id, array('enrollment_err' => $enrollmentErr, 'already_enrolled_user' => $alreadyEnrolledUser, 'enrollment_suc' => $enrollmentSuc));
        }

        public function get_csv_users_response_data($user_id, $cohort_id, $enrollmentErr, $alreadyEnrolledUser, $enrollmentSuc)
        {

            // return get_option($user_id .'_'.$cohort_id);
            $data = get_option($user_id .'_'.$cohort_id);
            delete_option($user_id .'_'.$cohort_id);

            return $data;

        }






        /**
         * Checkes whether the all the data submited is correct to create the user
         * @param type $data array of post data
         * @return returns true if the data is incrrect and false if the data is correct
         */
        private function is_invalid_user_req_data($data)
        {
            $keyArr = array("mdl_cohort_id", "firstname", "lastname", "email");
            foreach ($keyArr as $key) {
                if (!$this->check_is_empty($data, $key)) {
                    return true;
                }
            }
            return false;
        }

        /**
         * Check is the array value is present for the key
         * @param type $data array of the data
         * @param type $key key to check
         * @return true if the user array contains the value for the key ,false otherwise
         */
        private function check_is_empty($data, $key)
        {
            if (isset($data[$key]) && !empty($data[$key])) {
                return $data[$key];
            } else {
                return false;
            }
        }

        /**
         * Currently not using this function we will remopve it.
         * Process the user account creation request,
         * Checks is the user account exist or not and prepeares the user object
         * and creates the user on wordpress
         * @param type $email user email address
         * @param type $firstname user first name
         * @param type $lastname use last name
         * @return Object WP_User returns the WP_user object for the given email address.
         */
        private function process_user_acc_creation($email, $firstname, $lastname)
        {
            $user = null;
            $user_id = edwiserBridge\edwiserBridgeInstance()->userManager()->createWordpressUser($email, $firstname, $lastname);


            if (!empty($user_id) && !is_wp_error($user_id)) {
                $user = get_userdata($user_id);

                $cohortManager = new BPCohortManageUser();
                $cohortManager->updateMoodleUserProfile(5, $user->ID);
            } elseif (is_wp_error($user_id) && strpos($user_id->get_error_data(), 'eb_email_exists') !== false) {
                $user = get_user_by("email", $email);
                $language = 'en';
                if (isset($general_settings['eb_language_code'])) {
                    $language = $general_settings['eb_language_code'];
                }

                $moodle_user = edwiserBridge\edwiserBridgeInstance()->userManager()->getMoodleUser($email);

                if (isset($moodle_user['user_exists']) && $moodle_user['user_exists'] == 1 && is_object($moodle_user['user_data'])) {
                    update_user_meta($user->ID, 'moodle_user_id', $moodle_user['user_data']->id);
                    // sync courses of an individual user when an existing moodle user is linked with a wordpress account.
                    edwiserBridge\edwiserBridgeInstance()->userManager()->userCourseSynchronizationHandler(array('eb_synchronize_user_courses' => 1), $user->ID);
                } else {
                    $password = wp_generate_password();
                    $user_data = array(
                        'username' => $user->user_login,
                        'password' => $password,
                        'firstname' => $firstname,
                        'lastname' => $lastname,
                        'email' => $email,
                        'auth' => 'manual',
                        'lang' => $language,
                    );
                    $moodle_user = edwiserBridge\edwiserBridgeInstance()->userManager()->createMoodleUser($user_data, 0);
                    if (isset($moodle_user['user_created']) && $moodle_user['user_created'] == 1 && is_object($moodle_user['user_data'])) {
                        update_user_meta($user->ID, 'moodle_user_id', $moodle_user['user_data']->id);
                        $args = array(
                            'user_email' => $email,
                            'username' => $user->user_login,
                            'first_name' => $firstname,
                            'last_name' => $lastname,
                            'password' => $password,
                        );
                        // do_action('eb_created_user', $args);
                        //create a new action hook with user details as argument.
                        do_action('eb_linked_to_existing_wordpress_to_new_user', $args);
                    }
                }
            }
            return $user;
        }

        /**
         * Check is the user is enrolled for the all the users
         * @param type $ebCourseIds  array of the cohort corse ids
         * @param type $userId the user id for to check is the user enrolled for the courses
         * @return boolean true if the user is already enrolled to the all the courses, otherwise false
         */
        private function is_user_already_enrolled($ebCourseIds, $userId)
        {
            global $wpdb;
            $mdlEnroll = $wpdb->prefix . "moodle_enrollment";
            $stmtUserEnroll = "select course_id from {$mdlEnroll} where user_id='$userId'";
            $result = $wpdb->get_col($stmtUserEnroll);
            if (array_intersect($ebCourseIds, $result) === $ebCourseIds) {
                return true;
            } else {
                return false;
            }
        }

        /**
         * Currently not using this function ned to remove it
         * Function to check if the user is enrolled successfuly or not
         * @param String $email, array $alreadyEnrolledUser, array $enrollment_err
         * return  $email if success or null
         */
        public function check_if_enrolled_successfully($email, $alreadyEnrolledUser, $enrollment_err)
        {
            if (!in_array($email, $alreadyEnrolledUser) && !in_array($email, $enrollment_err)) {
                return true;
            } else {
                return false;
            }
        }

        /**
         * Currently not using this function Need to remove it.
         * function to get array products having commomn courses used while updating moodleenrollment table.
         * @param  [type] $arr product.
         * @param  [type] $courseId searched in tghe product array.
         * @return [type]      [description]
         */
        public function get_product_array($products, $courseId)
        {
            global $wpdb;
            $products = unserialize($products);
            //array for the products with associated courses
            $productArray = [];
            $tableName = $wpdb->prefix . "woo_moodle_course";
            foreach ($products as $key => $value) {
                unset($value);
                $query = $wpdb->prepare("SELECT moodle_post_id FROM $tableName WHERE product_id = %d", $key);
                $results = $wpdb->get_col($query);
                if (in_array($courseId, $results)) {
                    array_push($productArray, $key);
                }
            }
            return $productArray;
        }

        /**
         * updating cohort product quantity on enrollment
         * @param  [type] $cohortId  [description]
         * @param  [type] $productId [description]
         * @return [type]            [description]
         */
        public function update_bp_cohort_info_table_on_enrollment($cohortId, $remQty)
        {
            global $wpdb;
            $tableName = $wpdb->prefix . "bp_cohort_info";
            $query = $wpdb->prepare("SELECT PRODUCTS FROM $tableName WHERE MDL_COHORT_ID = %d", $cohortId);
            $results = $wpdb->get_var($query);
            $cohortProd = unserialize($results);
            foreach ($cohortProd as $prodId => $qty) {
                $qty=$qty;
                $cohortProd[$prodId]=$remQty;
            }
            $cohortProd = serialize($cohortProd);
            $query = $wpdb->prepare(
                "update `{$tableName}` set PRODUCTS = %s WHERE MDL_COHORT_ID = %d",
                $cohortProd,
                $cohortId
            );
            $wpdb->query($query);
        }

        public function get_cohort_details($mdlCohortId)
        {
            global $wpdb;
            $tablName = $wpdb->prefix . "bp_cohort_info";
            $query = $wpdb->prepare("SELECT MDL_COHORT_ID, PRODUCTS, COURSES, COHORT_NAME, NAME FROM $tablName WHERE mdl_cohort_id = %d", $mdlCohortId);
            $results = $wpdb->get_row($query, ARRAY_A);
            $productsArray = $results['PRODUCTS'];
            $products = unserialize($results['PRODUCTS']);
            $courses = unserialize($results['COURSES']);
            $products = array_values($products);
            $minQuantity = min($products);
            return array("quantity" => $minQuantity, "name" => $results['NAME'] != "" ? $results['NAME'] : $results['COHORT_NAME'], "courses" => $courses, "products" => $productsArray, "mdl_cohort_id" => $results['MDL_COHORT_ID']);
        }



        /**
         * Creates the orderd list of users.
         *
         * @param type $emailArray array of the email addreses.
         * @version 1.1.0
         * @return HTML orderd list of the email addresses.
         *
         */
        private function create_email_list($emailArray)
        {
            ob_start();
            ?>
            <ol>
                <?php
                foreach ($emailArray as $email) {
                    ?>
                    <li>
                        <?php echo $email; ?>
                    </li>
                    <?php
                }
                ?>
            </ol>
            <?php
            return ob_get_clean();
        }

        public function update_wordpres_user_role($userId, $email)
        {
            $cuserId = get_current_user_id();
            $userInfo = get_userdata($cuserId);
            if (!user_can($userId, 'manage_options')) {
                $user = new \WP_User($userId);
                if ($userInfo->user_email == $email) {
                    $user->add_role('non_editing_teacher');
                } else {
                    $user->add_role('subscriber');
                }
            } else {
                $user = new \WP_User($userId);
                if ($userInfo->user_email == $email) {
                    $user->add_role('non_editing_teacher');
                } else {
                    $user->add_role('subscriber');
                }
            }
        }

        /**
         * Provides the functionality to fetch the moodle course post ids with the product ids
         *
         * @param Array $product Array of the product ids
         * @since 2.0.0
         * @return Array returns the array of the product ids with associated courses.
         */
        private function get_product_courses($product)
        {
            global $wpdb;
            $tbl_name = $wpdb->prefix . "woo_moodle_course";
            $ebCourseIds=array();
            $stmt="SELECT DISTINCT `product_id`,`moodle_post_id` FROM `{$tbl_name}` WHERE `product_id` in ('".implode("','", $product)."');";
            $result=$wpdb->get_results($stmt, ARRAY_A);
            foreach ($result as $rec) {
                $ebCourseIds[$rec['moodle_post_id']]=$rec['product_id'];
            }
            return $ebCourseIds;
        }

        /**
         * Functionality to update the enrollment records on enroll in to the cohort
         *
         * @param int $mdlCohortId moodle cohort id
         * @param int $user_id User id to enroll into the course
         * @param int $currUserId current user id
         * @param string $userRole Enrolled user role
         * @param Array $prodIds Array of the product cohort ids.
         * @since 2.0.0
         * @return boolean returns true on sucessfull DB update
         */
        protected function enroll_user($mdlCohortId, $user_id, $currUserId, $userRole, $prodIds)
        {
            global $wpdb;
            $status=false;
            $prodIds=  unserialize($prodIds);
            $coursePostIds=$this->get_product_courses(array_keys($prodIds));
            foreach ($coursePostIds as $courseId => $prodId) {
                    $status=$wpdb->insert(
                        $wpdb->prefix.'moodle_enrollment',
                        array(
                        'user_id' => $user_id,
                        'course_id' => $courseId,
                        'role_id' => "5",
                        'time' => date('Y-m-d H:i:s'),
                        'enrolled_by' => $currUserId,
                        'product_id' => $prodId,
                        'mdl_cohort_id' => $mdlCohortId,
                        'role' => $userRole,
                            ),
                        array(
                        '%d',
                        '%d',
                        '%d',
                        '%s',
                        '%s',
                        '%d',
                        '%d',
                        '%d',
                        '%s',
                            )
                    );
            }
            return $status;
        }
    }
}
