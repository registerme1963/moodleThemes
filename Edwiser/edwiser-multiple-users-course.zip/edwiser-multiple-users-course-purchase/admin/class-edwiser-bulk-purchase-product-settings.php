<?php
/**
 *
 */
namespace app\wisdmlabs\edwiserBridge\BulkPurchase;

/**
 * 
 */
class Edwiser_Bulk_Purchase_product_Settings
{
	
	function __construct()
	{
		// woocommerce_product_after_variable_attributes

	}




	public function wdm_process_variation_grp_field($variation_id, $key)
	{
		$this->wdm_save_group_purchase_field($variation_id, $key);
	}





    public function wdm_display_group_purchase_fields($product_id)
    {
        global $post;

        $checked = 'on';
        $current = 'off';
        $currentReuseQty ='off';
        // $product_id = $post->ID;
        $product_options = get_post_meta($product_id, 'product_options', true);
        $wrap_class = 'ebbp_product_settings_wrap';
        $style = '';
        $_product = wc_get_product($product_id);

        // if( $_product->is_type( 'simple' ) ){
        if( false !== $_product && ( $_product->is_type( 'simple' ) || $_product->is_type( 'subscription' )) ){
            $wrap_class = '';
            // $style = 'style="margin:unset;"';

            // simple product
        }


        if (isset($product_options['moodle_course_group_purchase'])
         && !empty($product_options['moodle_course_group_purchase'])
         ) {
            $current = $product_options['moodle_course_group_purchase'];
        }

        if (isset($product_options['bp_reuse_quantity'])
         && !empty($product_options['bp_reuse_quantity'])
         ) {
            $currentReuseQty = $product_options['bp_reuse_quantity'];
        }

        ?>
        <div class="<?= $wrap_class ?>">
	        <div class="ebbp_product_settings show_if_simple">
	            <p class='form-field'>
	                <label <?= $style ?>>
	                    <?php _e('Group Purchase', 'ebbp-textdomain');?>
	                </label>
	                <input type="checkbox" class="moodle_course_group_purchase" name ="moodle_course_group_purchase[]" <?php echo ($checked == $current) ? 'checked' : '' ?> >
	                <img class="help_tip" data-tip='<?php _e('Allow user to purchase course product in bulk.', 'ebbp-textdomain') ?>' src="<?php echo esc_url(WC()->plugin_url());?>/assets/images/help.png" height="16" width="16" />
	                
	                <!-- Adding this hidden input box because unchecked checkbopxes dont submit any value but in case of the variation we need it. -->
	                <input type="hidden" class="moodle_course_group_purchase_hidden" name ="moodle_course_group_purchase_hidden[]" value="<?php echo ($checked == $current) ? 'on' : 'off' ?>" >

	            </p>
	        </div>

	        <div class="ebbp_product_settings bp-reuse-qty-contain <?php echo ($checked == $current) ? 'bp-show' : 'bp-hide' ?>">
	            <p class='form-field'>
	                <label <?= $style ?>>
	                    <?php _e('Reuse quantity after user is removed from the group', 'ebbp-textdomain');?>
	                </label>
	                <input type="checkbox" class="bp_reuse_quantity" name ="bp_reuse_quantity[]" value="off" <?php echo ($checked == $currentReuseQty) ? 'checked' : '' ?> >
	                <img class="help_tip" data-tip='<?php _e('User can reuse the seats again even after removing users from group.', 'ebbp-textdomain') ?>' src="<?php echo esc_url(WC()->plugin_url());?>/assets/images/help.png" height="16" width="16" />

	                <!-- Adding this hidden input box because unchecked checkbopxes dont submit any value but in case of the variation we need it. -->
	                <input type="hidden" class="bp_reuse_quantity_hidden" name ="bp_reuse_quantity_hidden[]" value="<?php echo ($checked == $currentReuseQty) ? 'on' : 'off' ?>" >

	            </p>
	        </div>
	    </div>
        <?php
        
        //add hook here.

    }




	public function wdm_save_group_purchase_field($variation_id = 0, $key = 0)
    {
        // if (isset($_POST['ID']) && isset($_POST['product-type']) ) {

            $post_id = isset($_POST['ID']) ? $_POST['ID'] : 0;
            $post_type = get_post_type($post_id);

            if ($variation_id) {
	            $post_id = $variation_id;
            }
 
            // if (isset($_POST[$post_type . '_options']) && !empty($_POST[$post_type . '_options'])) {
            if ($post_id) {

                $product_options = get_post_meta($post_id,  'product_options', true);

                if (!isset($product_options) || !is_array($product_options)) {
                    $product_options = array();
                }

                if (isset($_POST['moodle_course_group_purchase_hidden'][$key]) &&
                    !empty($_POST['moodle_course_group_purchase_hidden'][$key])) {
                
                    $product_options['moodle_course_group_purchase'] = $_POST['moodle_course_group_purchase_hidden'][$key];

                    if (isset($_POST['bp_reuse_quantity_hidden'][$key]) && !empty($_POST['bp_reuse_quantity_hidden'][$key])) {
                        $product_options['bp_reuse_quantity'] = $_POST['bp_reuse_quantity_hidden'][$key];
                    }

                    // update_post_meta($post_id, '_sold_individually', '');
                } else {

                    $product_options['moodle_course_group_purchase'] = 'off';
                    // update_post_meta($post_id, '_sold_individually', 'yes');
                }

                update_post_meta($post_id, 'product_options', $product_options);

            // }
        // }
        }






/*if (isset($_POST['bridge_woo_variation_option'][$key])) {

                if (is_array($_POST['bridge_woo_variation_option'][$key])) {
                    array_walk($_POST['bridge_woo_variation_option'][$key], array($this, 'bridgeWooArrayEscAttr'));
                    $moodle_post_ids['moodle_post_course_id'] = $_POST['bridge_woo_variation_option'][$key];
                } else {
                    $moodle_post_ids['moodle_post_course_id'] = esc_attr($_POST['bridge_woo_variation_option'][$key]);
                }
            } else {
                // No data to save
                $moodle_post_ids['moodle_post_course_id'] = "-1";
            }
*/




    }




}
