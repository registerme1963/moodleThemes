<?php

namespace app\wisdmlabs\edwiserBridge\BulkPurchase;

// if (!class_exists('\app\wisdmlabs\edwiserBridge\BulkPurchase\Eb_Bp_Enroll_Students_Course_Progress')) {

    class Eb_Bp_Enroll_Students_Course_Progress
    {

    	public function __construct()
		{
			# code...
		}






		public function get_cohort_course_progress()
		{
		    global $wpdb;
		    if (isset($_POST['cohort_id']) && !empty($_POST['cohort_id']) && isset($_POST['user_id']) && !empty($_POST['user_id'])) {
		        $mdl_cohort_id = $_POST['cohort_id'];
		        $user_id      = $_POST['user_id'];

		        $table_name = $wpdb->prefix . "bp_cohort_info";
		        $query = $wpdb->prepare("SELECT COURSES FROM $table_name WHERE MDL_COHORT_ID = %d;", $mdl_cohort_id);
		        $cohort_courses = maybe_unserialize($wpdb->get_var($query));

		        $notCompleted = 0;
		        $responseArray = array();
		        if (!empty($cohort_courses)) {
		            $user_course_progress = $this->get_course_progress($user_id);

		            $html  = '<div id="ebbp_custom_field_dialog_wrap" title="'.__('Course Progress', 'ebbp-textdomain').'">';
		            $html .= '<table class="ebbp_custom_field_tbl">';
		            $html .= '<thead class="ebbp_custom_field_tbl_thead">
		                        <tr>
		                            <th> ' . __('Course Name', 'ebbp-textdomain') . '</th>
		                            <th> ' . __('Progress', 'ebbp-textdomain') . '</th>
		                        </tr>
		                    </thead>
		                    <tbody class="ebbp_custom_field_tbl_body">';

		            foreach ($cohort_courses as $value) {
		                // if () {

		                    $html .= '<tr>
		                                <td>' . get_the_title($value) . '</td>
		                                <td> 
		                                	<progress id="file" value="'. ceil($user_course_progress[$value]) .'" max="100"> '. ceil($user_course_progress[$value]) . "%" . '
		                                	</progress> '. ceil($user_course_progress[$value]) . "%" .'
		                                </td>
		                            </tr>';
		                // }
		                // $responseArray[get_the_title($key)] = ceil($value) . "%";
		            }

		            $html .= '</tbody>
		                </table>
		            </div>';
		        }

		        wp_send_json_success($html);
		    }

		}




		public function get_course_progress($user_id)
		{

		    global $wpdb;

		    $mdl_user_id = get_user_meta($user_id, "moodle_user_id", true);

		    if ($mdl_user_id) {
		        $webservice_function = "eb_get_course_progress";
		        $request_data = array('user_id' => $mdl_user_id); // prepare request data array


		        $response = \app\wisdmlabs\edwiserBridge\edwiserBridgeInstance()->connectionHelper()->connectMoodleWithArgsHelper(
		            $webservice_function,
		            $request_data
		        );


		        $course_progress_array = array();

		        if (isset($response["success"]) && $response["success"]) {
		            foreach ($response["response_data"] as $value) {
		                // $courseId = getWpCourseIdFromMoodleCourseId($value->course_id);
		                $course_id = $wpdb->get_var("SELECT post_id FROM {$wpdb->prefix}postmeta WHERE meta_value={$value->course_id} AND meta_key = 'moodle_course_id'");
		                $course_progress_array[$course_id] = $value->completion;
		            }
		        }

		        // update_user_meta($userId, "moodle_course_progress", serialize($courseProgressArray));
		        return $course_progress_array;
		    }
		    return 0;
		}


    }

// }

