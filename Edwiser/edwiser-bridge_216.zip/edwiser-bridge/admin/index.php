<?php
/**
 * Silence is golden.
 * /
