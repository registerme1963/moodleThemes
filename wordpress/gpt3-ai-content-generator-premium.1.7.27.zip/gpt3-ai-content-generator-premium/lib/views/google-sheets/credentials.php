<?php
if ( ! defined( 'ABSPATH' ) ) exit;
?>
<tr>
    <th><?php echo esc_html__('Credentials','gpt3-ai-content-generator')?></th>
    <td><input type="file" name="file" class="wpaicg_sheets_first_credentials"></td>
</tr>
<tr>
    <th></th>
    <td><button class="button button-primary wpaicg_sheets_save"><?php echo esc_html__('Save','gpt3-ai-content-generator')?></button></td>
</tr>
